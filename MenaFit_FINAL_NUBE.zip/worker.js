const ADMIN_KEY = "Y4wgQR0DWQI-pk_hLA0zOSkJKcRCKBox1vD_jnlhHuA";

function cors(){return {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,PUT,OPTIONS','Access-Control-Allow-Headers':'Content-Type,X-MenaFit-Admin'}}
function resp(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json',...cors()}})}
export default {
 async fetch(request,env){
  if(request.method==='OPTIONS') return new Response('',{headers:cors()});
  const url=new URL(request.url);
  if(url.pathname==='/api/state' && request.method==='GET'){const raw=await env.MENAFIT_KV.get('state'); return resp(raw?JSON.parse(raw):{clients:[]});}
  if(url.pathname==='/api/state' && request.method==='PUT'){if(request.headers.get('X-MenaFit-Admin')!==ADMIN_KEY)return resp({error:'No autorizado'},401); const body=await request.json(); await env.MENAFIT_KV.put('state',JSON.stringify(body)); for(const c of (body.clients||[])) await env.MENAFIT_KV.put('client:'+c.id,JSON.stringify(c)); return resp({ok:true});}
  if(url.pathname.startsWith('/api/client/') && request.method==='GET'){const id=decodeURIComponent(url.pathname.slice('/api/client/'.length)); const raw=await env.MENAFIT_KV.get('client:'+id); return raw?resp(JSON.parse(raw)):resp({error:'Cliente no encontrado'},404);}
  return env.ASSETS.fetch(request);
 }
};
